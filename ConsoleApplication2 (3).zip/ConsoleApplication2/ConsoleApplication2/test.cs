﻿using System;
using System.IO;
using System.Web;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenXMLExcel.SLExcelUtility;

namespace ConsoleApplication2
{
    class test
    {
        public static void Main(string[] args)
        {
            var data = new SLExcelData();
            SLExcelReader read = new SLExcelReader();
            data=read.ReadExcel();
            Console.ReadLine();
            byte[] stringArray = new byte[100];  
            SLExcelWriter write = new SLExcelWriter();
             write.GenerateExcel(data);

        }
    }
}
